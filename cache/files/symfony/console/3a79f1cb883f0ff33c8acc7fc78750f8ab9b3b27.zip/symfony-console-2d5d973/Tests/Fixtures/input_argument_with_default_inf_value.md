#### `argument_name`

argument description

* Is required: no
* Is array: no
* Default: `INF`
